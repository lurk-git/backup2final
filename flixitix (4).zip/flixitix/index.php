<?php
include 'db.php'; // or the correct relative path

header("Location: ProfilePage/ProfilePage.php");
exit();
?>
